CREATE TABLE `author` (
                          `id` int NOT NULL AUTO_INCREMENT,
                          `name` varchar(45) DEFAULT NULL,
                          PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `songs` (
                         `id` int NOT NULL AUTO_INCREMENT,
                         `name` varchar(100) DEFAULT NULL,
                         `lyrics` varchar(10000) DEFAULT NULL,
                         `link` varchar(450) DEFAULT NULL,
                         `author_id` int DEFAULT NULL,
                         PRIMARY KEY (`id`),
                         KEY `author_id_idx` (`author_id`),
                         CONSTRAINT `author_id` FOREIGN KEY (`author_id`) REFERENCES `author` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb3;

CREATE TABLE `slines` (
                          `id` int NOT NULL AUTO_INCREMENT,
                          `stext` varchar(500) DEFAULT NULL,
                          `song_id` int DEFAULT NULL,
                          PRIMARY KEY (`id`),
                          KEY `song_id_idx` (`song_id`),
                          CONSTRAINT `FK2wwj429e6txh0q1ui19fy6o0j` FOREIGN KEY (`song_id`) REFERENCES `songs` (`id`),
                          CONSTRAINT `song_id` FOREIGN KEY (`song_id`) REFERENCES `songs` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=461 DEFAULT CHARSET=utf8mb3;

CREATE TABLE `words` (
                         `id` int NOT NULL AUTO_INCREMENT,
                         `wordOrder` int DEFAULT NULL,
                         `word` varchar(150) DEFAULT NULL,
                         `showed` tinyint(1) DEFAULT NULL,
                         `sline_id` int DEFAULT NULL,
                         PRIMARY KEY (`id`),
                         KEY `sline_id` (`sline_id`),
                         CONSTRAINT `FKmtbnm6neqw3um8hojsj5e122q` FOREIGN KEY (`sline_id`) REFERENCES `slines` (`id`),
                         CONSTRAINT `sline_id` FOREIGN KEY (`sline_id`) REFERENCES `slines` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=2585 DEFAULT CHARSET=utf8mb3;