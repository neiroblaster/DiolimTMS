package tms.shchayuk.audition.entity;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "slines")
public class Line {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "stext")
    private String stext;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "song_id")
    private Song song;

    @OneToMany(mappedBy = "sline", cascade = CascadeType.ALL)
    List<Word> listOfWords;

    public Line() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getStext() {
        return stext;
    }

    public void setStext(String stext) {
        this.stext = stext;
    }

    public Song getSong() {
        return song;
    }

    public void setSong(Song song) {
        this.song = song;
    }

    public List<Word> getListOfWords() {
        return listOfWords;
    }

    public void setListOfWords(List<Word> listOfWords) {
        this.listOfWords = listOfWords;
    }

    @Override
    public String toString() {
        return "Line{" +
                "id=" + id +
                ", text='" + stext + '\'' +
                ", song=" + song +
                '}';
    }
}
