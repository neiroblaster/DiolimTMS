package tms.shchayuk.audition.entity;

import org.springframework.stereotype.Component;

import javax.persistence.*;

@Entity
@Table(name = "words")
public class Word {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "wordOrder")
    private int wordOrder;

    @Column(name = "word")
    private String word;

    @Column(name = "showed")
    private boolean showed = true;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "sline_id")
    private Line sline;

    public Word() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public Line getSline() {
        return sline;
    }

    public void setSline(Line sline) {
        this.sline = sline;
    }

    public int getWordOrder() {
        return wordOrder;
    }

    public void setWordOrder(int wordOrder) {
        this.wordOrder = wordOrder;
    }

    public boolean isShowed() {
        return showed;
    }

    public void setShowed(boolean showed) {
        this.showed = showed;
    }
}
