package tms.shchayuk.audition.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import tms.shchayuk.audition.entity.*;

import java.util.*;
import java.util.stream.Collectors;

@Repository
public class AuditionDAOImpl implements AuditionDAO {

    @Autowired
    private SessionFactory sessionFactory;

    @Autowired
    private AnswersFromDAO answersFromDAO;

    @Autowired
    private Answers answers;

    @Override
    public Song getSongById(int id) {
        Session session = sessionFactory.getCurrentSession();

        Song song = session.get(Song.class, id);
        return song;
    }

    @Override
    public void deleteSong(int id) {
        Session session = sessionFactory.getCurrentSession();
        Song song = session.load(Song.class, id);
        if (song != null){
            session.delete(song);
        }
    }

    @Override
    public List<Song> getAllSongs() {
        Session session = sessionFactory.getCurrentSession();

        Query<Song> query = session.createQuery("from Song", Song.class);
        List<Song> allSongs = query.getResultList();
        return allSongs;
    }

    @Override
    public List<Word> splitAndSaveWordsBySongId(int id) {
        Session session = sessionFactory.getCurrentSession();
        Song song = session.get(Song.class, id);

        if (song.getListOfLines() != null) {
            Query<Line> query = session.createQuery("delete from Line " +
                    "where song.id =:id");
            query.setParameter("id", id);
            query.executeUpdate();
        }
        String lyrics = song.getLyrics();
        List<String> createdLines = Arrays.asList(lyrics.split("\r\n"));

        List<Line> lines = new ArrayList<>();
        Line line;
        for (String savedLine : createdLines) {
            if (!savedLine.equals(""))
            {
            line = new Line();
            line.setStext(savedLine);
            lines.add(line);
            line.setSong(song);
            }
        }

        List<Word> words = new ArrayList<>();


        for (Line everyLine : lines) {
            List<String> createdWords = new ArrayList<>(Arrays.stream(everyLine.getStext()
                    .split("\\p{P}?[ \\t\\n\\r]+")).collect(Collectors.toList()));
//            List<String> createdWords = Arrays.stream(everyLine.getStext().split(" ")).collect(Collectors.toList());
            int wordOrder = 1;
            for (String savedWord : createdWords) {
                Word word = new Word();
                word.setWord(savedWord);
                word.setWordOrder(wordOrder);
                words.add(word);
                word.setSline(everyLine);
                wordOrder++;
            }
        }

        song.setListOfLines(lines);

        for (Line sline : lines) {
            sline.setListOfWords(words);
        }

        return words;
    }

    @Override
    public void saveSong(Song song) {
        Session session = sessionFactory.getCurrentSession();

        session.saveOrUpdate(song);

    }

    @Override
    public List<Line> getAllLinesBySongId(int id) {
        Session session = sessionFactory.getCurrentSession();
        Song song = session.get(Song.class, id);
        List<Line> listOfLines = song.getListOfLines();
        return listOfLines;
    }

    @Override
    public String showSong(int id) {
        return null;
    }

    @Override
    public List<String> doStrategy(List<Word> allWords, List<Line> allLines) {

        answers.getAnswerList().clear();
        List<String> answersFromDAOfirst = new ArrayList<>();
        String wordToCompare = "";

        for (Line curLine : allLines) {
            Random random = new Random();
            int randomWord = random.nextInt(curLine.getListOfWords().size()) + 1;
            for (Word curWord : curLine.getListOfWords()) {
                if (curWord.getWordOrder() == randomWord) {
                    Answer answer = new Answer();
                    answer.setRightAnswer(curWord.getWord());
                    answer.setSongId(curLine.getSong().getId());
                    answer.setLineId(curLine.getId());
                    answer.setWordId(curWord.getId());

                    curWord.setShowed(false);
                    wordToCompare = curWord.getWord();
                    curWord.setWord(null);
                    answersFromDAOfirst.add(wordToCompare);

                    answers.addOneAnswer(answer);
                }
            }
        }
        answersFromDAO.setAnswersFromDAO(answersFromDAOfirst);

        return answersFromDAOfirst;
    }
}