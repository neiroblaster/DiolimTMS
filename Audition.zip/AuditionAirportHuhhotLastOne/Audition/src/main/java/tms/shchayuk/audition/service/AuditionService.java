package tms.shchayuk.audition.service;

import tms.shchayuk.audition.entity.*;

import java.util.List;

public interface AuditionService {

    public List<Song> getAllSongs ();

    public List<Word> splitAndSaveWordsBySongId (int id);

    public void saveSong(Song song);

    public void deleteSong (int id);

    public List<Line> getAllLinesBySongId (int id);

    public String showSong (int id);

    public List <String> doStrategy(List<Word> allWords, List<Line> allLines);

    public Song getSongById(int id);
}
