package tms.shchayuk.audition.entity;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class Answers {

    private List<Answer> answerList = new ArrayList<>();

    public Answers() {
    }

    public List<Answer> getAnswerList() {
        return answerList;
    }

    public void setAnswerList(List<Answer> answerList) {
        this.answerList = answerList;
    }

    public void addOneAnswer (Answer answer){
        answerList.add(answer);
    }
}
