package tms.shchayuk.audition.entity;

import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class AnswersFromClient {

    private List<String> answersFromClient;

    public AnswersFromClient() {
    }

    public List<String> getAnswersFromClient() {
        return answersFromClient;
    }

    public void setAnswersFromClient(List<String> answersFromClient) {
        this.answersFromClient = answersFromClient;
    }
}
