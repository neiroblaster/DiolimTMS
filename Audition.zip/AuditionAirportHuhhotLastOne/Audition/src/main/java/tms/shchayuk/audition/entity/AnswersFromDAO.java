package tms.shchayuk.audition.entity;

import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class AnswersFromDAO {

    private List<String> answersFromDAO;

    public AnswersFromDAO() {
    }

    public List<String> getAnswersFromDAO() {
        return answersFromDAO;
    }

    public void setAnswersFromDAO(List<String> answersFromDAO) {
        this.answersFromDAO = answersFromDAO;
    }
}
