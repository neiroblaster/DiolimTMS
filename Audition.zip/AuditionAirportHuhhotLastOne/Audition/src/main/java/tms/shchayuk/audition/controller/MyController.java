package tms.shchayuk.audition.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import tms.shchayuk.audition.entity.*;
import tms.shchayuk.audition.service.AuditionService;

import java.util.*;
import java.util.stream.Collectors;

@Controller
public class MyController {

    @Autowired
    private AuditionService auditionService;

    @Autowired
    private AnswersFromClient answersFromClient;

    @Autowired
    private AnswersFromDAO answersFromDAO;

    @Autowired
    private Answers answers;


    @RequestMapping("/")
    public String showAllSongs(Model model) {


        List<Song> allSongs = auditionService.getAllSongs();
        model.addAttribute("allSongs", allSongs);

        return "all-songs";
    }

    @RequestMapping("/splitAndSaveWordsBySongId")
    public String splitAndSaveWordsBySongId(@RequestParam("songId") int id, Model model) {

        List<Word> allWords = auditionService.splitAndSaveWordsBySongId(id);
        List<Line> allLines = auditionService.getAllLinesBySongId(id);
        model.addAttribute("allWords", allWords);
        model.addAttribute("allLines", allLines);

        return "all-songs";

    }

    @RequestMapping("/showSong")
    public String showSong(@RequestParam("songId") int id, Model model) {

        List<Line> allLines = auditionService.getAllLinesBySongId(id);
        List<Word> allWordsNotSorted = new ArrayList<>();
        for (Line currentLine : allLines) {
            allWordsNotSorted.addAll(currentLine.getListOfWords());
        }
        List<Word> allWords = allWordsNotSorted.stream().sorted(Comparator.comparingInt(Word::getWordOrder)).collect(Collectors.toList());

        auditionService.doStrategy(allWords, allLines);
        AnswersFromClient answersFromClient = new AnswersFromClient();

        model.addAttribute("allLines", allLines);
        model.addAttribute("allWords", allWords);
        model.addAttribute(answersFromDAO);
        model.addAttribute(answersFromClient);
        return "show-song";
    }

    @RequestMapping("/checkAnswers")
    public String checkAnswers(@ModelAttribute AnswersFromClient answersFromClient,
                               Model model) {

        List<Line> allLines = auditionService.getAllLinesBySongId(answers.getAnswerList().get(0).getSongId());
        List<Word> allWordsNotCompared = new ArrayList<>();
        for (Line currentLine : allLines) {
            allWordsNotCompared.addAll(currentLine.getListOfWords());
        }
        List<Word> allWords = allWordsNotCompared.stream().sorted(Comparator.comparingInt(Word::getWordOrder)).collect(Collectors.toList());
        model.addAttribute("allLines", allLines);
        model.addAttribute("allWords", allWords);


        List<String> aFClient = answersFromClient.getAnswersFromClient()
                .stream().collect(Collectors.toList());
        for (int i = 0; i < aFClient.size(); i++) {
            answers.getAnswerList().get(i).setClientAnswer(aFClient.get(i));
            if (answers.getAnswerList().get(i).getRightAnswer().toLowerCase(Locale.ROOT).equals(aFClient.get(i).toLowerCase(Locale.ROOT))) {
                answers.getAnswerList().get(i).setCheck(true);
            } else {
                answers.getAnswerList().get(i).setCheck(false);
            }
        }

        model.addAttribute("answers", answers);
        return "show-answers";
    }

    @RequestMapping("/addNewSong")
    public String addNewSong(Model model) {

        Song song = new Song();
        model.addAttribute("song", song);

        return "song-info";
    }

    @RequestMapping("/saveSong")
    public String saveSong(@ModelAttribute("song") Song song) {

            auditionService.saveSong(song);
            int songId = song.getId();
            auditionService.splitAndSaveWordsBySongId(songId);

        return "redirect:/";
    }

    @RequestMapping("/deleteSong")
    public String deleteSong(@RequestParam("songId") int id) {

        auditionService.deleteSong(id);

        return "redirect:/";
    }
}
