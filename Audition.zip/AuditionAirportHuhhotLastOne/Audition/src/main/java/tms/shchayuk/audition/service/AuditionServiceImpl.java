package tms.shchayuk.audition.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tms.shchayuk.audition.dao.AuditionDAO;
import tms.shchayuk.audition.entity.*;

import java.util.List;

@Service
public class AuditionServiceImpl implements AuditionService {

    @Autowired
    private AuditionDAO auditionDAO;

    @Override
    @Transactional
    public List<Song> getAllSongs() {
        return auditionDAO.getAllSongs();
    }

    @Override
    @Transactional
    public List<Word> splitAndSaveWordsBySongId(int id) {
        return auditionDAO.splitAndSaveWordsBySongId(id);
    }

    @Override
    @Transactional
    public void saveSong(Song song) {
        auditionDAO.saveSong(song);
    }

    @Override
    @Transactional
    public void deleteSong(int id) {
        auditionDAO.deleteSong(id);
    }

    @Override
    @Transactional
    public List<Line> getAllLinesBySongId(int id) {
        return auditionDAO.getAllLinesBySongId(id);
    }

    @Override
    @Transactional
    public String showSong(int id) {
        return auditionDAO.showSong(id);
    }

    @Override
    @Transactional
    public List <String> doStrategy(List<Word> allWords, List<Line> allLines){
        return auditionDAO.doStrategy(allWords, allLines);
    }

    @Override
    @Transactional
    public Song getSongById(int id) {
        return auditionDAO.getSongById(id);
    }

}
